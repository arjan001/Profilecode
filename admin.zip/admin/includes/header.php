<div class="page-title-overlap bg-accent pt-4">
        <div class="container d-flex flex-wrap flex-sm-nowrap justify-content-center justify-content-sm-between align-items-center pt-2">
          <div class="d-flex align-items-center pb-3">
            <div class="img-thumbnail rounded-circle position-relative flex-shrink-0" style="width: 6.375rem;"><img class="rounded-circle" src="../img/marketplace/account/avatar.png" alt="ProfileCode"></div>
            <div class="ps-3">
              <h3 class="text-light fs-lg mb-0">ADMIN PAGE</h3>
            </div>
          </div>

        </div>
      </div>